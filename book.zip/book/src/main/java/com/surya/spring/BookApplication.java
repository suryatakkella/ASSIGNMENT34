package com.surya.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SpringBootApplication
public class BookApplication {

  @RequestMapping(value = "/surya")
  public String available() {
    return "SPRING ACTION BY SURYA";
  }

  @RequestMapping(value = "/checked-out")
  public String checkedOut() {
    return "SPRING BOOT ACTION BY SURYA";
  }

  public static void main(String[] args) {
    SpringApplication.run(BookApplication.class, args);
  }
}